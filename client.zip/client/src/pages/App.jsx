import Header from "../components/header/header";
import "./App.css";

const App = () => {
  return (
    <div>
      <Header />
    </div>
  );
};

export default App;
