import styles from "./header.module.css";

import patinha from "../../assets/patinha.svg";
import search from "../../assets/search.svg";
import people from "../../assets/people.svg";
import heart from "../../assets/heart.svg";
import bag from "../../assets/bag.svg";

const Header = () => {
  return (
    <div className={styles.header}>

      <div className={styles.logo}>
        Little Pet
        <img src={patinha} alt="" />
      </div>

      <div>
        <input type="text" />
        <img src={search} alt="" />
      </div>

      <div className={styles.login}>
        <img src={people} alt="" />
        <div>
          <p>Entrar</p>
          <p>Cadastrar</p>
        </div>
      </div>

      <div className={styles.social}>
        <img src={heart} alt="" />
        <img src={bag} alt="" />
      </div>

    </div>
  );
};

export default Header;
